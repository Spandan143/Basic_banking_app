1. Install requiremnts.txt into your system.

pip install -r requirements.txt


2. create a MongoDB database 'bank'
	create database bank;

3. create 2 collections inside bank   'customers', 'transactions'
	use bank;
	db.createCollection('customers')
	db.createCollection('transactions')

4. insert data from data.json file to customers collection
	db['customers'].insertMany(< text from data.json>)

5. modify model.py with new credentials.

6. run >  python app.py