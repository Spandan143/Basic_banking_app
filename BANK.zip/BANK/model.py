import pymongo as pm 
from datetime import datetime

# Connect to MongoDB
client = pm.MongoClient("mongodb+srv://ankushmulewar51:OtFoH1q1aSUDYlW0@bankapplication.dru7scb.mongodb.net/?retryWrites=true&w=majority&appName=BankApplication")

database_name = 'bank'
db = client[database_name]


def getAllAccountNumbers():
    cursor = db['customers'].find()
    return cursor

def getAllTransactions():
    cursor = db['transactions'].find()
    return cursor

def getTransactions(account_number):
    cursor = db['transactions'].find({'$or' :[{'account_to' : account_number , 'status':'success'}, {'account_from': account_number, 'status' : 'success'}]})
    return cursor


def createTransaction(data):
    last_transaction_id = db['transactions'].find_one({}, sort=[("transaction_id", -1)])['transaction_id']
    data['transaction_id'] = last_transaction_id + 1
    data['timestamp'] = datetime.now()
    db['transactions'].insert_one(data)


def getAllCustomers():
    cursor = db["customers"].find()
    return cursor


def getCustomerData(customer_id):
    cursor = db["customers"].find({"customer_id": customer_id})
    for document in cursor:
        return document


def checkBalance(account_number):
    cursor = db["customers"].find({"account_number": account_number})
    for document in cursor:
        return document["account_balance"]
    

def debitMoney(account_number, amount):
    db["customers"].update_one({"account_number": account_number}, {"$inc": {"account_balance": -amount}})


def creditMoney(account_number, amount):
    db["customers"].update_one({"account_number": account_number}, {"$inc": {"account_balance": amount}})


# print(1,checkBalance('1000001'))
# print(2,checkBalance('1000002'))

# debitMoney('1000001', 1000)
# creditMoney("1000002", 1000)

# print(1,checkBalance('1000001'))
# print(2,checkBalance('1000002'))
